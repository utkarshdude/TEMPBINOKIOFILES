<?php
session_start();
include("INC/COOKIEIP.php");

 ?>
<?PHP
    include_once("CONFIG.php");

    if(isset($_SESSION['BATTLEPLEXIP'])){
        
    $id = strval($_SESSION['BATTLEPLEXIP']);


  if(!isset($_GET['BATTLEID'])){
    ?>
<script>
    window.location = "ERROR.php?CODE=1";

</script>
<?php

  }else{
   

    $battleid = stripslashes($_GET['BATTLEID']);
      $battleid = htmlspecialchars($battleid, ENT_QUOTES, 'UTF-8');

      $stmt = $conn->prepare("SELECT * FROM battle WHERE battleid = ? AND battleid NOT IN (SELECT bid FROM total WHERE IP = ?)");
      $stmt->execute([$battleid,$_SESSION['BATTLEPLEXIP']]);

      if($stmt->rowCount() == 0){
          
          $pass = $conn->prepare("SELECT * FROM battle WHERE battleid = ?");
          $pass->execute([$battleid]);
          $res = $pass->fetch(PDO::FETCH_OBJ);

        ?>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">
    <meta name="author" content="Utkarsh Rai">
    <meta property="og:image" content="<?php echo $res->thumbnail; ?>">
    <meta property="og:title" content="<?php echo ''.$res->Name1.' Vs '.$res->Name2.''; ?>">
    <meta property="og:description" content="Vote Your Choice.">
    <meta property="og:description" content="Vote Your Choice.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <script data-ad-client="ca-pub-7469549945146624" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    <title>VOTED</title>
    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="stylesheet" href="CSS/Media.css">


    <script src="JS/Jquery.js"></script>
</head>

<body >



   <!-- <center>
        <div class="filler">
            <h2>Sorry!</h2><br>
            <p>Either The Battle Is No More Active</p><br>
            <p><b>OR</b></p><br>
            <p>You Have Already Voted.</p>
            <br>
            <a href="Score.php?BattleID=<?php #echo $battleid; ?>" style="width:200px; padding:10px; border:1px solid #1a1a1a; background:#fff; color:#1a1a1a; text-decoration:none;">Go To Results</a>

        </div>
    </center>-->
    
    <script>

        window.location = 'Score.php?BattleID=<?php echo $battleid; ?>';
    
    </script>
</body>

</html>
<?php

      }else{
$pass = $conn->prepare("SELECT * FROM battle WHERE battleid = ?");
          $pass->execute([$battleid]);
          $res = $pass->fetch(PDO::FETCH_OBJ);
        
        ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
    <meta property="og:image" content="https://www.binokio.com/Battleplex/<?php echo substr($res->thumbnail, 1); ?>">
    <meta property="og:url"   content="https://www.binokio.com/Battleplex/Vote.php?BATTLEID=<?php echo $battleid; ?>">
    <meta property = "fb:app_id" content="2403678373271860">
    <meta property="og:type"     content="website" >
    <meta property="og:title" content="<?php echo ''.$res->Name1.' Vs '.$res->Name2.''; ?>">
    <meta property="og:description" content="Vote Your Choice.">
    <script data-ad-client="ca-pub-7469549945146624" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?php echo ''.$res->Name1.' Vs '.$res->Name2.''; ?></title>
    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="stylesheet" href="CSS/Media.css">


    <script src="JS/Jquery.js"></script>
</head>
<?php

        
          
          $todayday = substr(date('d/m/Y'),0,2);
          $todaymonth = substr(date('d/m/Y'),3,2);
              
          $endday = substr($res->end_date,0,2);
          $endmonth = substr($res->end_date,3,2);
          
          if($res->status == '0' || $todayday == $endday && $todaymonth == $endmonth || $todayday > $endday && $todaymonth == $endmonth){
              
              $change = $conn->prepare("UPDATE `battle` SET status = '0' WHERE battleid = ?");
              $change->execute([$res->battleid]);
              
               ?>

<!--<center>

    <p style="color:#1a1a1a; padding:20px;">Sorry! Voting Has Been Closed For This Battle.</p>
    <br>
    <a href="Score.php?BattleID=<?php #echo $res->battleid; ?>" style="width:200px; padding:10px; border:1px solid #1a1a1a; background:#fff; color:#1a1a1a; text-decoration:none;">Go To Results</a>
</center>-->

<script>
    
    window.location = 'Score.php?BattleID=<?php echo $res->battleid; ?>';
    
    </script>

<?php
              
          }else{
           
              
          
?>


<body style="overflow-x:hidden;">
    <div class="header">
        <!--  <img src="BATTLEPLEX.png" alt=""> -->
         <img src="BATTLEPLEX_HEADER.png" alt="">
    </div>
    <br>


    <center>

        <?php

                    $votecount_1 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
                    $votecount_1->execute([$res->imageid1]);

                    $count_1 = $votecount_1->rowCount();

                    $votecount_2 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
                    $votecount_2->execute([$res->imageid2]);

                    $count_2 = $votecount_2->rowCount();

            ?>

        <div class="frameCont">
            <div class="framesizer" id="FRAME<?php echo $res->battleid; ?>">

                <!--                <input type="hidden" value="<?php# echo $ip_address; ?>" id="MYIP">
-->
                <input type="hidden" id="page" value="vote">
                <div class="frame" id="<?php echo $res->battleid; ?>">
                    <div class="innerframe innerframe1" id="VOTEANDIMAGE<?php echo $res->imageid1;?>">
                        <div id="IMAGEFRAME" style="width:auto; height:auto; position:relative;">
                            <img src="UPLOADS/<?php echo $res->image1; ?>" data-result="<?php echo $res->Name1; ?>" class="clickableimage" data-id="<?php echo $res->battleid; ?>" id="<?php echo $res->imageid1; ?>" alt="">
                            <p id="votecount" value="<?php echo $count_1; ?>" style=""><?php echo $count_1; ?></p>

                        </div>
                        <div class="label">
                            <center><p class="labels labelname"><?php echo $res->Name1; ?></p></center>
<!--
                            <p class="labels instaid"><a href="https://www.instagram.com/<?php echo $res->InstaID1; ?>">@<?php echo $res->InstaID1; ?></a></p>
                            -->
                        </div>
                    </div>
                    <div class="innerframe innerframe2" id="VOTEANDIMAGE<?php echo $res->imageid2;?>">
                        <div id="IMAGEFRAME" style="width:auto; height:auto; position:relative;">
                            <img src="UPLOADS/<?php echo $res->image2; ?>" data-result="<?php echo $res->Name2; ?>" data-id="<?php echo $res->battleid; ?>" class="clickableimage" id="<?php echo $res->imageid2; ?>" alt="">
                            <p id="votecount" value="<?php echo $count_2; ?>"><?php echo $count_2; ?></p>

                        </div>
                        <div class="label">
                            <center><p class="labels labelname"><?php echo $res->Name2; ?></p></center>
                            <!--
                            <p class="labels instaid"><a href="https://www.instagram.com/<?php echo $res->InstaID2; ?>">@<?php echo $res->InstaID2; ?></a></p>
                            -->
                        </div>
                    </div>
                    

                </div>
                <div style="padding:30px;">
                <p style="font-size:20px; text-align:left; margin-top:5px; color:#fff; padding:10px;">CLICK ON PARTICIPANT'S IMAGE TO VOTE</p>
        
        <p style="font-size:20px; text-align:left; margin-top:5px; color:#fff; padding:10px;">वोट करने के लिए प्रतिभागी की फोटो पर क्लिक करें</p>
           </div>
                <p id="result<?php echo $res->battleid; ?>"></p>
               <!--
                <div class="BtnHolder" id="btn<?php echo $res->battleid; ?>">
                    <button class="voteBtn" value="<?php echo $res->battleid; ?>" id="<?php echo $res->imageid1; ?>">A</button>
                    <button class="voteBtn" value="<?php echo $res->battleid; ?>" id="<?php echo $res->imageid2; ?>">B</button>
                </div>
               -->
            </div>
           
        </div>
        
        
        
    </center>

    <?php


      }
      }




  }
 }else{
        
    }


?>
    <style media="screen">
        @@media (max-width: 500px) {


            .frame {
                justify-content: center;
                flex-direction: column;
            }

            .innerframe {
                width: 60%;
            }
        }

        .innerframe {
            width: 80% !important;
        }

        .filler h2 {
            color: #fff;
            padding: 10px;
        }

        .filler p {
            color: #ddd;
            line-height: 25px;
            padding: 20px;
        }

    </style>
    <script src="JS/VOTE.js" charset="utf-8"></script>
</body>

</html>
