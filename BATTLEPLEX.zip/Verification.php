<?php
include_once('CONFIG.php');
  if(isset($_GET['Token']) && isset($_GET['USER'])){

$token = stripslashes($_GET['Token']);
    $token = htmlspecialchars($token, ENT_QUOTES, 'UTF-8');

    $user = stripslashes($_GET['USER']);

    $user = htmlspecialchars($user, ENT_QUOTES, 'UTF-8');

    $check = $conn->prepare("SELECT * FROM `users` WHERE User_ID = ? AND Token = ?");
    $check->execute([$user,$token]);

    if($check->rowCount() != 0){

      $change = $conn->prepare("UPDATE `users` SET Status = '1' WHERE User_ID = ? AND Token = ?");
      $change->execute([$user,$token]);
      $change = $conn->prepare("UPDATE `users` SET Token = '' WHERE User_ID = ? AND Token = ?");
      $change->execute([$user,$token]);
       echo "<script>window.location = 'index.php';</script>";

    }else{
      echo "<script>window.location = 'ERROR.php?CODE=1';</script>";
    }

  }else{

  }


 ?>
