$(document).ready(function(){
  $('#FORMLOGIN').submit(function(e) {
e.preventDefault();
  email = $('input[name = "email"]').val();
  pass = $('input[name = "pass"]').val();



      $.ajax({
        url:"INC/Login.php",
        type:"POST",
        data: {
          email:email,
          pass:pass
        },

        cache:false,
        beforeSend:function(){

        },
        success:function(data){
          if(jQuery.trim(data) == '1'){
            if($('#redirect').val() != '' && $('#redirect').val() != null){
              var redirect = $('#redirect').val();
              window.location = redirect;
            }else{
            window.location = "index.php";
            }

          }else{
            $('#errorpane').html(data);
          }
        }
      });




  });
});
