<?php
session_start();

include_once("../CONFIG.php");


if(isset($_POST['iid'])){

    
    
if(isset($_SESSION['BATTLEPLEXIP'])){
    
    
   $best_known_ip = strval($_SESSION['BATTLEPLEXIP']);
    
    
}else{
    
    
    if (!function_exists('getClientIP'))
    {
        function getClientIP()
            {
                if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) 
                    {
                        $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                    };

                foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
                    {
                        if (array_key_exists($key, $_SERVER)) 
                            {
                                foreach (explode(',', $_SERVER[$key]) as $ip)
                                    {
                                        $ip = trim($ip);

                                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                                            {
                                                return $ip;
                                            };
                                    };
                            };
                    };

                return false;
            };
    };

$best_known_ip = getClientIP();
    
    
}


    
    

  $iid = stripslashes($_POST['iid']);
  $iid = htmlspecialchars($iid, ENT_QUOTES, 'UTF-8');
  $bid = stripslashes($_POST['bid']);
  $bid = htmlspecialchars($bid, ENT_QUOTES, 'UTF-8');
  
   $check = $conn->prepare("SELECT * FROM total WHERE IP = ? AND bid = ?");
    $check->execute([$_SESSION['BATTLEPLEXIP'] , $bid]);
    
    if($check->rowCount() == 0){
        
        $stmt = $conn->prepare("INSERT INTO `total`(bid,imageid,User_ID,Name,Email,IP) VALUES (?,?,'','','',?)");
    $stmt->execute([$bid,$iid,$best_known_ip]);
        
    }else{
        
        echo '0';
        
    }


    


}else{
    echo "no data";
}
?>
