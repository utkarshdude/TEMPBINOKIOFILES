
    $(document).ready(function() {


      $("body").on('click', '.clickableimage', function(e) {

          var battleid = $(this).attr('data-id');

          var imageid = $(this).attr("id");
          var result = $(this).attr('data-result');
          
          $(this).attr('class', '');

          $.ajax({

              url: "INC/Vote.php",
              type: "POST",
              data: {
                  bid: battleid,
                  iid: imageid
              },
              cache: false,
              beforeSend: function() {

                $('#IMAGEFRAME img').attr('class' , 'ABORTED');
                  $('#VOTEANDIMAGE'+imageid+' #votecount').css('display' , 'block');
                var old = $('#VOTEANDIMAGE'+imageid+' #votecount').html();
                old = +old+1;
                $('#VOTEANDIMAGE'+imageid+' #votecount').html(old);
              },
              success: function(data) {

              //  $('#btn'+battleid).html("<p style='color:#ec4d37; font-size:17px; padding:5px;'>You Voted For "+result+"</p>");
                //$('#FRAME'+battleid).html("<p style='color:#ec4d37; font-size:17px; padding:5px;'>You Voted For "+result+"</p>");
                
                  if(jQuery.trim(data) == "0"){
                      
                      if($('#page').val() == 'vote'){
                      window.location = 'Score.php?BattleID='+battleid+'';
                  }
                  if($('#page').val() == 'index'){
                      window.location = '';
                  }
                      
                  }
                
                  
                  if($('#page').val() == 'vote'){
                      window.location = 'Score.php?BattleID='+battleid+'';
                  }
                  if($('#page').val() == 'index'){
                      window.location = '';
                  }
            }

          });

      });



        $("body").on('click', '.voteBtn', function() {

            var battleid = $(this).val();

            var imageid = $(this).attr("id");
            var result = $(this).html();

            $.ajax({

                url: "INC/Vote.php",
                type: "POST",
                data: {
                    bid: battleid,
                    iid: imageid
                },
                cache: false,
                beforeSend: function() {

                    $('#btn'+battleid).html("<p style='color:#ec4d37; font-size:17px; padding:5px;'>You Voted For "+result+"</p>");
                },
                success: function() {


                }

            });

        });
    });
