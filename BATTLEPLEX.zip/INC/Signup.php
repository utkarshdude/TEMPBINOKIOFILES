<?php
session_start();
if(isset($_POST['name'])){

  include_once('../CONFIG.php');

  $name = stripslashes($_POST['name']);
  $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
  $email = stripslashes($_POST['email']);
  $email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
  $pass = stripslashes($_POST['pass']);
  $pass = htmlspecialchars($pass, ENT_QUOTES, 'UTF-8');
    $rawpass = $pass;

  $emailcheck = $conn->prepare("SELECT * FROM `users` WHERE Email = ?");
  $emailcheck->execute([$email]);

  if($emailcheck->rowCount() == 0){
      
      
      
      
      

/* Get the 'best known' client IP. */

if (!function_exists('getClientIP'))
    {
        function getClientIP()
            {
                if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) 
                    {
                        $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                    };

                foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
                    {
                        if (array_key_exists($key, $_SERVER)) 
                            {
                                foreach (explode(',', $_SERVER[$key]) as $ip)
                                    {
                                        $ip = trim($ip);

                                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                                            {
                                                return $ip;
                                            };
                                    };
                            };
                    };

                return false;
            };
    };

$best_known_ip = getClientIP();
      
      
      
      

      $options = [
          'cost' => 12,
      ];
      $pass =  password_hash($pass, PASSWORD_BCRYPT, $options);
      $userID = md5(uniqid());
      $token = md5(uniqid());
      $token = password_hash($token, PASSWORD_DEFAULT);

      $stmt = $conn->prepare("INSERT INTO `users` (User_ID,Name,Email,Password,status,Token,IP) VALUES (?,?,?,?,'0',?,?)");
      if($stmt->execute([$userID,$name,$email,$pass,$token,$best_known_ip])){
         include_once('ENCDEC.php');
            
          echo "1";
          $_SESSION['LOGIN_SESSION'] = $userID;
            
            

           $ciphering = "AES-128-CTR"; 
  
// Use OpenSSl Encryption method 
$iv_length = openssl_cipher_iv_length($ciphering); 
$options = 0; 
  
// Non-NULL Initialization Vector for encryption 
$encryption_iv = '1452541536987458'; 
  
// Store the encryption key 
$encryption_key = "145fg5454f8d2f4cv8d8f5f4d98df5df64df4d4f4df4"; 
  
// Use openssl_encrypt() function to encrypt the data 
            $USERDATA = openssl_encrypt($userID, $ciphering, 
            $encryption_key, $options, $encryption_iv);
            
            $USERDATA2 = openssl_encrypt($rawpass, $ciphering, 
            $encryption_key, $options, $encryption_iv);
            
            
            setcookie("BATTLEPLEXDATA", $USERDATA . "," . $USERDATA2, time() + (365 * 24 * 60 * 60), "/");



        $to = $email;
        $subject = 'Battleplex - Email Varification';
        $from = 'no-reply@Binokio.com';

        // To send HTML mail, the Content-type header must be set
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

        // Create email headers
        $headers .= 'From: '.$from."\r\n".
            'Reply-To: '.$from."\r\n" .
            'X-Mailer: PHP/' . phpversion();

        // Compose a simple HTML email message
        $message = '
         <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Mail From Binokio Seller</title>
        </head>
        <body style="font-family: arial; background:;">
           <center><div style="width:98%;  padding-bottom:20px;">
            <div class="header" style="background:#ec5d36; width:100%; padding-top:5px; padding-bottom:5px;">
                <center><img src="https://binokio.com/Img/logo.png" alt="" style="height:70px;"></center>
            </div>
            <div class="content">
                <p style="padding: 20px; padding-bottom:10px; font-size:20px; color:#1a1a1a;">THANKS FOR CONNECTING WITH BATTLEPLEX</p>

                <h2 style="padding: 20px; padding-bottom:10px; font-size:20px; color:#1a1a1a;">To Verify Your Account Click The Link Below -</h2>
                <br><center>';
                $message .= '
                   battleplex.binokio.com/Battleplex/Verification.php?Token='.$token.'&USER='.$userID.'';
  $message .= '</center>
            </div></div></center>
        </body>
        </html>';




        // Sending email
      mail($to, $subject, $message, $headers);


      }else{
        echo "0";
      }

  }else{

    echo 'Account With This Email Already Exists! <a href="Login.php">Login Here!</a>';

  }


}else{

}
 ?>
