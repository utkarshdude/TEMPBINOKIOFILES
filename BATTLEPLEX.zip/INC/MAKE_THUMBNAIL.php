<?php

$img1 = $_GET['img1'];
$img2 = $_GET['img2'];
$id = $_GET['id'];
include_once("../CONFIG.php");

/*
 $image = imagecreatefromstring(file_get_contents($img1));
  $coffe_mug= imagecreatefromstring(file_get_contents($img2));

  // merge the two
  imagecopymerge($image, $coffe_mug, 0, 0, 0, 0, 100, 47, 75);

  // save, can also be imagepng, imagegif, etc, etc
  imagejpeg($image, '../THUMBNAIL/image.png');
*/


$img1_path = $img1;
$img2_path = $img2;
$thumbnail = md5(uniqid());

list($img1_width, $img1_height) = getimagesize($img1_path);
list($img2_width, $img2_height) = getimagesize($img2_path);

$merged_width  = $img1_width + $img2_width;
//get highest
$merged_height = $img1_height > $img2_height ? $img1_height : $img2_height;

$merged_image = imagecreatetruecolor($merged_width, $merged_height);

imagealphablending($merged_image, false);
imagesavealpha($merged_image, true);

$img1 = imagecreatefromstring(file_get_contents($img1_path));
$img2 = imagecreatefromstring(file_get_contents($img2_path));

imagecopy($merged_image, $img1, 0, 0, 0, 0, $img1_width, $img1_height);
//place at right side of $img1
imagecopy($merged_image, $img2, $img1_width, 0, 0, 0, $img2_width, $img2_height);

//save file or output to broswer
$SAVE_AS_FILE = TRUE;
if( $SAVE_AS_FILE ){
    $save_path = "../THUMBNAIL/".$thumbnail.".jpg";
    imagepng($merged_image,$save_path);
}else{
    header('Content-Type: image/jpeg');
    imagejpeg($merged_image);
}

//release memory
imagedestroy($merged_image);

$fullpath = substr($save_path,2);

$stmt = $conn->prepare("UPDATE `battle` SET thumbnail = ? WHERE battleid = ?");
if($stmt->execute([$fullpath,$id])){
    ?>
    
    <script>
        
        window.location = "../ADMINS/Admin.php";

</script>
    
    <?php
}



?>