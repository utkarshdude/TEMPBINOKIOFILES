<?php
session_start();
  if(isset($_SESSION['LOGIN_SESSION'])){

    echo "YOU ARE ALREADY LOGGED IN!";

  }else{
    include_once('../CONFIG.php');
    if(isset($_POST['email'])){

      $email = stripslashes($_POST['email']);
      $email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
      $pass = stripslashes($_POST['pass']);
      $pass = htmlspecialchars($pass, ENT_QUOTES, 'UTF-8');

      $stmt = $conn->prepare("SELECT * FROM `users` WHERE Email = ?");
      $stmt->execute([$email]);

      if($stmt->rowCount() == 0){

        echo "Email Or Password Is Wrong. Try again!";

      }else{

        $fetch = $stmt->fetch(PDO::FETCH_OBJ);

        $password = $fetch->Password;
        $userID = $fetch->User_ID;



        if(password_verify($pass , $password)){

            
            
            
            

/* Get the 'best known' client IP. */

if (!function_exists('getClientIP'))
    {
        function getClientIP()
            {
                if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) 
                    {
                        $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                    };

                foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
                    {
                        if (array_key_exists($key, $_SERVER)) 
                            {
                                foreach (explode(',', $_SERVER[$key]) as $ip)
                                    {
                                        $ip = trim($ip);

                                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                                            {
                                                return $ip;
                                            };
                                    };
                            };
                    };

                return false;
            };
    };

$best_known_ip = getClientIP();
            
            
            
            
            
          echo "1";
          $_SESSION['LOGIN_SESSION'] = $userID;
            
            $ss = $conn->Prepare("UPDATE `users` SET IP = ? WHERE User_ID = ?");
            $ss->execute([$best_known_ip,$userID]);
            
            $ciphering = "AES-128-CTR"; 
  
// Use OpenSSl Encryption method 
$iv_length = openssl_cipher_iv_length($ciphering); 
$options = 0; 
  
// Non-NULL Initialization Vector for encryption 
$encryption_iv = '1452541536987458'; 
  
// Store the encryption key 
$encryption_key = "145fg5454f8d2f4cv8d8f5f4d98df5df64df4d4f4df4"; 
  
// Use openssl_encrypt() function to encrypt the data 
            $USERDATA = openssl_encrypt($userID, $ciphering, 
            $encryption_key, $options, $encryption_iv);
            
            $USERDATA2 = openssl_encrypt($pass, $ciphering, 
            $encryption_key, $options, $encryption_iv);
           

            
            
            setcookie("BATTLEPLEXDATA", $USERDATA . "," . $USERDATA2, time() + (365 * 24 * 60 * 60), "/", "binokio.com", 0);


        }else{
          echo "Email Or Password Is Wrong. Try again!";
        }

      }

    }

  }

 ?>
