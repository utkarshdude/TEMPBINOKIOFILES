$(document).ready(function () {
    $('#FORMSIGNUP').submit(function (e) {
        e.preventDefault();
        var name = $('input[name="name"]').val();
        var email = $('input[name="email"]').val();
        var pass = $('input[name="pass"]').val();
        var cpass = $('input[name="cpass"]').val();

        if (jQuery.trim(name) != '' && jQuery.trim(email) != '' && jQuery.trim(pass) != '' && jQuery.trim(cpass) != '') {



            if (jQuery.trim(pass) == jQuery.trim(cpass)) {
      
                    
                $.ajax({
                    url: "INC/Signup.php",
                    type: "POST",
                    data: {
                        name: name,
                        email: email,
                        pass: pass
                    },
                    //processData:false,
                    cache: false,
                    beforeSend: function () {

                    },
                    success: function (data) {
                        if (jQuery.trim(data) == '1') {
                            if ($('#redirect').val() != '' && $('#redirect').val() != null) {
                                var redirect = $('#redirect').val();
                                window.location = redirect;
                            } else {
                                window.location = "index.php";
                            }
                        } else {
                            $('#errorpane').html(data);
                        }
                    }
                });
            
            
            

            } else {
                
                $('#errorpane').html("Password Does Not Match To Confirmation.<br>Please Try Again!");
            
            }




        } else {

            $('#errorpane').html("Please Fill Up All The Fields!");

        }






    });
});
