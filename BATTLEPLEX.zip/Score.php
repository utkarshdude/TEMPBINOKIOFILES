<?php
session_start();
include("INC/COOKIEIP.php");

 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>BATTLEPLEX</title>
    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">

    <link rel="stylesheet" href="CSS/Media.css">

<script data-ad-client="ca-pub-7469549945146624" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script src="JS/Jquery.js"></script>
</head>

<body>

    <?PHP
    include_once("CONFIG.php");

if(isset($_SESSION['BATTLEPLEXIP'])){
        
    $id = strval($_SESSION['BATTLEPLEXIP']);
    
    if(isset($_GET['BattleID'])){

        $id  = stripslashes($_GET['BattleID']);
        $id = htmlspecialchars($id, ENT_QUOTES, 'UTF-8');

        $fetch = $conn->prepare("SELECT * FROM battle WHERE battleid = ?");
        $fetch->execute([$id]);

        if($fetch->rowCount() != 0){

            $data = $fetch->fetch(PDO::FETCH_OBJ);
            
            
            $todayday = substr(date('d/m/Y'),0,2);
          $todaymonth = substr(date('d/m/Y'),3,2);
              
          $endday = substr($data->end_date,0,2);
          $endmonth = substr($data->end_date,3,2);
          
          if($data->status == '0' || $todayday == $endday && $todaymonth == $endmonth || $todayday > $endday && $todaymonth == $endmonth){
              
              $change = $conn->prepare("UPDATE `battle` SET status = '0' WHERE battleid = ?");
              $change->execute([$data->battleid]);
              
?>
             
             <?php

$votecount_1 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
$votecount_1->execute([$data->imageid1]);

$count_1 = $votecount_1->rowCount();

$votecount_2 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
$votecount_2->execute([$data->imageid2]);

$count_2 = $votecount_2->rowCount();

?>



    <?php

# SOME CONDITIONS ARE HERE-----------


if($count_1 > $count_2){

    $head_msg = "".$data->Name1." Won The Battle With ".$count_1." Vote.";

    $crown = 1;
    $resultmsg = "<p style='color:#ff6102;'>Congrats!! ".$data->Name1." You Won The Battle With ".$count_1." Votes.</p> <br><br> Better Luck Next Time ".$data->Name2." <br><br> <img src='ASSETS/DRAW.png' style='height:100px;'>";

}elseif($count_1 < $count_2){

    $crown = 2;
    $head_msg = "".$data->Name2." Won The Battle With ".$count_2." Vote.";
    $resultmsg = "<p style='color:#ff6102;'>Congrats!! ".$data->Name2." You Won The Battle With ".$count_2." Vote.</p> <br><br> Better Luck Next Time ".$data->Name1." <br><br> <img src='ASSETS/DRAW.png' style='height:100px;'>";

}elseif($count_1 == $count_2){
    $crown = 3;
    $head_msg = "Woops! Its a Draw.";
    
$resultmsg = "BETTER LUCK NEXT TIME FOR BOTH THE PARTICIPANTS.<br><br><img src='ASSETS/DRAW.png' style='height:100px;'>";

}


#END

?>



    <center><br>
        <h2 style="color:#fff; font-size:15px; font-weight:200; padding:10px; width:85%; border:1px solid #fff;"><?php echo $head_msg; ?></h2>
    </center>
    <br>

    <div style="width:100%; height:auto; padding-top:5px; padding-bottom:5px; display:flex; justify-content:space-around; align-items:; flex-direction:;">

        <div style="width:47%;">

            <?php
                    if($crown == 1){
                     ?>

            <script>
                $(document).ready(function() {
                    $('#crown1').css('visibility', 'visible');
                });

            </script>

            <?php   
                    }
                    ?>
            <center><img src="ASSETS/CROWN.png" id="crown1" alt="" style="height:50px; visibility:hidden;"></center>
            <div style="position:relative;"><img style="width:100%; " src="<?php echo substr($data->image1,3); ?>" alt="<?php echo $data->imageid1; ?>">
                <p style="position:absolute; top:0; width:50px; height:50px; color:#fff; line-height:50px; text-align:center; font-size:20px; background:#000;"><?php echo $count_1; ?></p>
            </div>

            <p style="color:#fff; background:#ff6102; text-align:center; font-size:20px; padding-top:10px; padding-bottom:10px; text-transform:uppercase;"><?php echo $data->Name1; ?></p>

            <script>
                //PERCENTAGE CALCULATION

                var count1 = <?php echo $count_1; ?>;
                var count2 = <?php echo $count_2; ?>;

                //FOR 1

                var percent1 = (count1) * 100 / (count1 + count2);
                //FOR 2
                var percent2 = (count2) * 100 / (count1 + count2);

                $(document).ready(function() {
                    $('#bar1').css('width', "" + percent1 + "%");
                    $('#bar2').css('width', "" + percent2 + "%");
                });

            </script>



        </div>
        <div style="width:47%;">
            <?php
                    if($crown == 2){
                     ?>

            <script>
                $(document).ready(function() {
                    $('#crown2').css('visibility', 'visible');
                });

            </script>
            <?php   
                    }
                    ?>
            <center><img src="ASSETS/CROWN.png" id="crown2" alt="" style="height:50px; visibility:hidden;"></center>
            <div style="position:relative;"><img style="width:100%; " src="<?php echo substr($data->image2,3); ?>" alt="<?php echo $data->imageid2; ?>">
                <p style="position:absolute; top:0; width:50px; height:50px; color:#fff; line-height:50px; text-align:center; font-size:20px; background:#000;"><?php echo $count_2; ?></p>
            </div>
            <p style="color:#fff; background:#ff6102; text-align:center; font-size:20px; padding-top:10px; padding-bottom:10px; text-transform:uppercase;"><?php echo $data->Name2; ?></p>




        </div>
    </div>
             
             <center>
                 
                 
                     <h2 style="color:#fff; padding:20px; font-size:20px;"><?php echo $resultmsg; ?></h2>
                 
                 
             </center>
             
             
             <?php
              
              
               
}else{
              ?>
              
              
              
             

    <?php

$votecount_1 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
$votecount_1->execute([$data->imageid1]);

$count_1 = $votecount_1->rowCount();

$votecount_2 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
$votecount_2->execute([$data->imageid2]);

$count_2 = $votecount_2->rowCount();

?>



    <?php

# SOME CONDITIONS ARE HERE-----------


if($count_1 > $count_2){

    $head_msg = "".$data->Name1." Is Wining The Battle With Extra ".($count_1-$count_2)." Votes.";

    $crown = 1;

}elseif($count_1 < $count_2){

    $crown = 2;
    $head_msg = "".$data->Name2." Is Wining The Battle With Extra ".($count_2-$count_1)." Vote.";

}elseif($count_1 == $count_2){
    $crown = 3;
    $head_msg = "Woops! Its a Draw Right Now.";

}


#END

?>



    <center><br>
        <h2 style="color:#fff; font-size:15px; font-weight:200; padding:10px; width:85%; border:1px solid #fff;"><?php echo $head_msg; ?></h2>
    </center>
    <br>

    <div style="width:100%; height:auto; padding-top:5px; padding-bottom:5px; display:flex; justify-content:space-around; align-items:; flex-direction:;">

        <div style="width:47%;">

            <?php
                    if($crown == 1){
                     ?>

            <script>
                $(document).ready(function() {
                    $('#crown1').css('visibility', 'visible');
                });

            </script>

            <?php   
                    }
                    ?>
            <center><img src="ASSETS/CROWN.png" id="crown1" alt="" style="height:50px; visibility:hidden;"></center>
            <div style="position:relative;"><img style="width:100%; " src="<?php echo substr($data->image1,3); ?>" alt="<?php echo $data->imageid1; ?>">
                <p style="position:absolute; top:0; width:50px; height:50px; color:#fff; line-height:50px; text-align:center; font-size:20px; background:#000;"><?php echo $count_1; ?></p>
            </div>

            <p style="color:#fff; background:#ff6102; text-align:center; font-size:20px; padding-top:10px; padding-bottom:10px; text-transform:uppercase;"><?php echo $data->Name1; ?></p>

            <script>
                //PERCENTAGE CALCULATION

                var count1 = <?php echo $count_1; ?>;
                var count2 = <?php echo $count_2; ?>;

                //FOR 1

                var percent1 = (count1) * 100 / (count1 + count2);
                //FOR 2
                var percent2 = (count2) * 100 / (count1 + count2);

                $(document).ready(function() {
                    $('#bar1').css('width', "" + percent1 + "%");
                    $('#bar2').css('width', "" + percent2 + "%");
                });

            </script>



        </div>
        <div style="width:47%;">
            <?php
                    if($crown == 2){
                     ?>

            <script>
                $(document).ready(function() {
                    $('#crown2').css('visibility', 'visible');
                });

            </script>
            <?php   
                    }
                    ?>
            <center><img src="ASSETS/CROWN.png" id="crown2" alt="" style="height:50px; visibility:hidden;"></center>
            <div style="position:relative;"><img style="width:100%; " src="<?php echo substr($data->image2,3); ?>" alt="<?php echo $data->imageid2; ?>">
                <p style="position:absolute; top:0; width:50px; height:50px; color:#fff; line-height:50px; text-align:center; font-size:20px; background:#000;"><?php echo $count_2; ?></p>
            </div>
            <p style="color:#fff; background:#ff6102; text-align:center; font-size:20px; padding-top:10px; padding-bottom:10px; text-transform:uppercase;"><?php echo $data->Name2; ?></p>




        </div>
    </div>
    <!--
    
    <div style="width:90%; padding:5px; display:flex; flex-direction:column;">


        <div style="display:flex; align-items:center; justify-content:space-around;">

            <img src="<?php echo substr($data->image2,3); ?>" style="height:70px;" alt="">

            <div class="progress" style="margin-left:10px;">

                <div class="progress-bar" id="bar2" width="">

                </div>
            </div>
        </div>
        <br>

        <div style="display:flex; justify-content:space-around; align-items:center;">

            <img src="<?php echo substr($data->image1,3); ?>" style="height:70px;" alt="">

            <div class="progress" style="margin-left:10px;">

                <div class="progress-bar" width="" id="bar1">

                </div>
            </div>
        </div>

    </div>
    
    -->

    <div>

        <p style="padding-top:20px; padding-left:20px; color:#fff; padding-bottom:5px;">Share Voting Link -</p><br>
        <center><textarea style="width:90%; border:1px solid #fff; resize:none; color:#fff; background:transparent;  padding:5px; height:50px;" readonly>https://www.binokio.com/Battleplex/Vote.php?BATTLEID=<?php echo $data->battleid; ?></textarea></center>
        <br><br><br><br><br>

    </div>
    
     <?php
              
          }
            
            ?>

    <?php

        }else{
            ?>
    <script>
        window.location = 'ERROR.php?CODE=1';

    </script>
    <?php
        }

    }else{

        ?>
    <script>
        window.location = 'ERROR.php?CODE=1';

    </script>
    <?php

    }

    ?>



<?php
    
}
    ?>



</body>

</html>
