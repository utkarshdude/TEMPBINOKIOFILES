<?php

  if(isset($_GET['CODE'])){

    $code = stripslashes($_GET['CODE']);

    if($code == 1){
      $ERRORMSG = 'We Are Sorry,<br><br>Something Went Wrong!';
    }

  }else{
    echo "<script>window.location = 'index.php';</script>";
  }

 ?>
 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="Utkarsh Rai">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>BATTLEPLEX</title>
     <link rel="stylesheet" href="CSS/Main.css">
     <link rel="stylesheet" href="CSS/Media.css">
     <link href="https://fonts.googleapis.com/css2?family=Lexend+Peta&display=swap" rel="stylesheet">
     <script src="JS/Jquery.js"></script>
 </head>

 <body>
<h1><?php echo $ERRORMSG; ?></h1>

   <style media="screen">
     body{
       background: #ec4d37;
       display: flex;

       height:100vh;
       align-items: center;
       justify-content: center;

     }

     h1 {
       color:#fff;
       font-family: 'Lexend Peta', sans-serif;
       font-size:30px;

     }
   </style>



 </body>
 </html>
