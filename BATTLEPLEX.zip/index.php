<?php
session_start();
include("INC/COOKIEIP.php");
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
    <link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>BATTLEPLEX</title>
    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="stylesheet" href="CSS/Media.css">
<script data-ad-client="ca-pub-7469549945146624" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    <script src="JS/Jquery.js"></script>
   
</head>

<body>
    <div class="header">
        <!--  <img src="BATTLEPLEX.png" alt=""> -->
   <img src="BATTLEPLEX_HEADER.png" alt="">
    </div>
    <br>
    <?PHP
    include_once("CONFIG.php");


if(isset($_SESSION['BATTLEPLEXIP'])){
        
    $id = strval($_SESSION['BATTLEPLEXIP']);
    
    
    ?>
    
    <input type="hidden" id="page" value="index">
    
    <?php

/*$checkvarify = $conn->prepare("SELECT * FROM `users` WHERE User_ID = ? AND Status = '0'");
$checkvarify->execute([$_SESSION['LOGIN_SESSION']]);

if($checkvarify->rowCount() != 0){
?>
    <div class="varificationAlert">
        <p>Please Varify Your Email Address.</p>
        <p>An Email For Varification Has Been sent To Your Provided Email Address.</p>
        <p>Check Your <b>SPAM</b> if Not visible.</p>

        <button type="button" name="" style="width:100px; border:none; color:#ec4d37; background:#fff; padding:10px;" onclick="CloseAlert()">CLOSE &times;</button>
        <script type="text/javascript">
            function CloseAlert() {
                $('.varificationAlert').css('display', 'none');
            }

        </script>
    </div>
    <?php

}else{


}*/


    function getUserIP()
    {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];

        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }
        else
        {
            $ip = $remote;
        }

        return $ip;
    }


    $user_ip = getUserIP();

  // Output IP address [Ex: 177.87.193.134]


    ?>
    <center>
        <div class="frameCont">
            <?php




      $stmt2 = $conn->prepare("SELECT * FROM battle WHERE battleid NOT IN (SELECT bid FROM total WHERE IP = ?) AND status != 0 ORDER BY id DESC");
      $stmt2->execute([$_SESSION['BATTLEPLEXIP']]);





      while($res = $stmt2->fetch(PDO::FETCH_OBJ)){

    ?>


            <div class="framesizer" id="FRAME<?php echo $res->battleid; ?>">

                <?php

                    $votecount_1 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
                    $votecount_1->execute([$res->imageid1]);

                    $count_1 = $votecount_1->rowCount();

                    $votecount_2 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
                    $votecount_2->execute([$res->imageid2]);

                    $count_2 = $votecount_2->rowCount();

            ?>


                <input type="hidden" value="<?php #echo $ip_address; ?>" id="MYIP">
                <input type="hidden" id="page" value="index">
                <div class="frame" id="<?php echo $res->battleid; ?>">
                    <div class="innerframe innerframe1" id="VOTEANDIMAGE<?php echo $res->imageid1;?>">
                        <div id="IMAGEFRAME" style="width:auto; height:auto; position:relative;">
                            <img src="UPLOADS/<?php echo $res->image1; ?>" data-result="<?php echo $res->Name1; ?>" class="clickableimage" data-id="<?php echo $res->battleid; ?>" id="<?php echo $res->imageid1; ?>" alt="">
                            <p id="votecount" value="<?php echo $count_1; ?>" style=""><?php echo $count_1; ?></p>

                        </div>
                        <div class="label">
                            <p class="labels labelname"><?php echo $res->Name1; ?></p>

                            <!--<p class="labels instaid"><a href="https://www.instagram.com/<?php echo $res->InstaID1; ?>">@<?php echo $res->InstaID1; ?></a></p>-->
                        </div>
                    </div>
                    <div class="innerframe innerframe2" id="VOTEANDIMAGE<?php echo $res->imageid2;?>">
                        <div id="IMAGEFRAME" style="width:auto; height:auto; position:relative;">
                            <img src="UPLOADS/<?php echo $res->image2; ?>" data-result="<?php echo $res->Name2; ?>" data-id="<?php echo $res->battleid; ?>" class="clickableimage" id="<?php echo $res->imageid2; ?>" alt="">
                            <p id="votecount" value="<?php echo $count_2; ?>"><?php echo $count_2; ?></p>

                        </div>
                        <div class="label">
                            <p class="labels labelname"><?php echo $res->Name2; ?></p>
                            <!--<p class="labels instaid"><a href="https://www.instagram.com/<?php echo $res->InstaID2; ?>">@<?php echo $res->InstaID2; ?></a></p>-->
                        </div>
                    </div>

                </div>
                <p id="result<?php echo $res->battleid; ?>"></p>
                <div class="BtnHolder" id="btn<?php echo $res->battleid; ?>">
                    <button class="voteBtn" value="<?php echo $res->battleid; ?>" id="<?php echo $res->imageid1; ?>">A</button>
                    <button class="voteBtn" value="<?php echo $res->battleid; ?>" id="<?php echo $res->imageid2; ?>">B</button>
                </div>
            </div>



            <?php
  }
        ?>
        </div>

    </center>
    <br>

    <div class="footOptions">
        <center><button class="footbutton" onclick="Resultpage(0)">Result</button></center>
        <script>
            function Resultpage() {
                window.location = 'Result.php';
            }

        </script>
    </div>

    <div class="footer">
        <ul>
            <li><a href="#">Wana Battle?</a></li>
            <li><a href="#">Apply For Admin</a></li>
            <li><a href="#">Developer</a></li>

        </ul>
        <br>
        <center>
            <h2 style="font-size: 15px; color:#fff;">Copyright &copy; BINOKIO 2020-2021</h2>
        </center>
    </div>
    <script src="JS/VOTE.js" charset="utf-8"></script>
    <?php }else{}  ?>

</body>

</html>
