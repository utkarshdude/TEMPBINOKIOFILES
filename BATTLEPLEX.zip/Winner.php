<?php

if(isset($_GET['BattleID']) && $_GET['BattleID'] != '' && $_GET['BattleID'] != null){
    
    include_once("CONFIG.php");
        
        $battleid = $_GET['BattleID'];
        $battleid = stripslashes($battleid);
        $battleid = htmlspecialchars($battleid, ENT_QUOTES, 'UTF-8');

        $stmt = $conn->prepare("SELECT * FROM battle WHERE battleid = ? AND status = 0");
        $stmt->execute([$battleid]);
    
        if($stmt->rowCount() != 0){
            
        $res = $stmt->fetch(PDO::FETCH_OBJ);
        
        }
    
    
        
     ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
    <meta property="og:image" content="www.binokio.com/Battleplex/ASSETS/CONGRATS2.jpg">
    <meta property="og:title" content="<?php echo ''.$res->Name1.' Vs '.$res->Name2.''; ?>">
    <meta property="og:description" content="Congratulating The Winner!">
    <link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>BATTLE WINNER</title>
    <link rel="stylesheet" href="CSS/Main.css">  
    <link rel="stylesheet" href="CSS/Media.css">


    <script src="JS/Jquery.js"></script>
</head>

<body>


    <?php
    
            
        $fetch = $conn->prepare("SELECT * FROM battle WHERE battleid = ? AND status = 0");
        $fetch->execute([$battleid]);
    
        if($fetch->rowCount() != 0){
            
        $data = $fetch->fetch(PDO::FETCH_OBJ);
        
        $votecount_1 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
        $votecount_1->execute([$data->imageid1]);
        $count_1 = $votecount_1->rowCount();
        $votecount_2 = $conn->prepare("SELECT * FROM `total` WHERE imageid = ?");
        $votecount_2->execute([$data->imageid2]);
        $count_2 = $votecount_2->rowCount();
                   
        if($count_1 > $count_2){
            
            ?>
    <script>
        $(document).ready(function() {
            $('#winnerimg').attr('src', 'UPLOADS/<?php echo $data->image1; ?>');
            $('#winnervotes').html('<?php echo $count_1; ?>');
            $('#winnername').html('<?php echo $data->Name1; ?>');
        });

    </script>
    <?php
                   
        }elseif ($count_2 > $count_1){
            
             ?>

    <script>
        $(document).ready(function() {
            $('#winnerimg').attr('src', 'UPLOADS/<?php echo $data->image2; ?>');
             $('#winnervotes').html('<?php echo $count_2; ?>');
            $('#winnername').html('<?php echo $data->Name2; ?>');
        });

    </script>

    <?php
        
        }elseif ($count_1 == $count_2){
            
             ?>

    <script>
        $(document).ready(function() {
            $('#winnerimg').attr('src', '');
        });

    </script>

    <?php
        
        }
    
        
        
            
        }else{
            
            ?>

    <script>
        
        window.location = 'ERROR.php?CODE=1';

    </script>

    <?php
            
        }
        ?>
    <div class="winnerimgtab" style="width:100%; height:100vh;">
       <center> <img src="ASSETS/CONGRATS.gif" alt="" style="height:170px;">
        <div style="position:relative;">
            <img src="ASSETS/CONGRATS.png" alt="" style="width:60%; position:absolute;">
            <img src="" alt="" id="winnerimg" style="width:60%;">
        </div>
        
        <div style="padding:22px;">
            
            <h3 id="winnername" style="font-size:20px; color:#fff; font-weight:200;"></h3><br>
            <p style="font-size:15px; color:#fff;">You Won The Battle With <b id="winnervotes"></b> votes.</p>
            
        </div>
        
        </center>

    </div>

</body>

</html>

<?php
    
}else{

    ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
    <link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>BATTLE WINNER</title>
    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="stylesheet" href="CSS/Media.css">


    <script src="JS/Jquery.js"></script>
</head>

<body>

    <script>
        window.location = 'ERROR.php?CODE=1';

    </script>
</body>

</html>


<?php
    
}

?>
