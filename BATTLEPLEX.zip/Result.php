<?php
session_start();
include("INC/COOKIEIP.php");

 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>BATTLEPLEX</title>
    <link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">

    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="stylesheet" href="CSS/Media.css">


    <script src="JS/Jquery.js"></script>
</head>

<body>

    
    <?PHP
    include_once("CONFIG.php");




    $voted = $conn->prepare("SELECT * FROM battle WHERE battleid IN (SELECT bid FROM total WHERE IP = ?)");
    $voted->execute([$_SESSION['BATTLEPLEXIP']]);

    if($voted->rowCount() != 0){

?>

<center>
            <div class="container" style="width:100%; height:100vh; display:flex; align-items:center; flex-direction:column; flex-wrap:wrap;">

<?php
        while($fetch = $voted->fetch(PDO::FETCH_OBJ)){

        

    ?>



                <a href="Score.php?BattleID=<?php echo $fetch->battleid; ?>" style="width:100%; color:#444; text-decoration:none;">
                <div class="listbox" style="">

                    <div style="width:50%; display:flex;">
                        <img src="<?php echo substr($fetch->image1,3); ?>" alt="">
                        <img src="<?php echo substr($fetch->image2,3); ?>" alt="">
                    </div>
                    <div><p><?php echo $fetch->Name1; ?> V/S <?php echo $fetch->Name2; ?></p></div>

                </div></a>

            


    <?php
        }
        ?>
        </div></center>
        <?php
     }else{
        ?>
        <center>
        <h3>You Have'nt Voted Any Battle Yet.</h3>
        <a href="index.php">VOTE NOW!</a>
        </center>
        <?php
    }

?>
</body>
</html>