<?php
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
$path2 = '../UPLOADS/'; // upload directory

$img = $_FILES['image2']['name'];
$tmp = $_FILES['image2']['tmp_name'];
// get uploaded file's extension
$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image = rand(1000,1000000).$img;

// check's valid format
if(in_array($ext, $valid_extensions)) 
{ 
$path2 = $path2.strtolower($final_image); 
    
    
    function compressImage($source, $destination, $quality) {

  $info = getimagesize($source);

  if ($info['mime'] == 'image/jpeg') 
    $image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
    $image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
    $image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

}
compressImage($_FILES['image2']['tmp_name'],$path2,60);
}

include_once("../CONFIG.php");

$path = '../UPLOADS/';
$img1 = $_FILES['img1']['name'];
$tmp1 = $_FILES['img1']['tmp_name'];
// get uploaded file's extension
$ext1 = strtolower(pathinfo($img1, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image1 = rand(1000,1000000).$img1;

// check's valid format
if(in_array($ext1, $valid_extensions)) 
{ 
$path = $path.strtolower($final_image1); 
    
    
compressImage($_FILES['img1']['tmp_name'],$path,60);
}

$battle = md5(uniqid());
$imageid1 = md5(uniqid());
$imageid2 = md5(uniqid());


    $date = date("d/m/Y");
    $tomorrow_date = date("d/m/Y", strtotime("+1 day"));
    $name1 = $_POST['name1'];
    $id1 = $_POST['id1'];
    $name2 = $_POST['name2'];
    $id2 = $_POST['id2'];
    
    $stmt = $conn->prepare("insert into `battle` (battleid,imageid1,image1,imageid2,image2,Name1,Name2,InstaID1,InstaID2,launch_date,end_date,status) values (?,?,?,?,?,?,?,?,?,?,?,'1')");
    if($stmt->execute([
        $battle,$imageid1,$path,$imageid2,$path2,$name1,$name2,$id1,$id2,$date,$tomorrow_date
    ])){
    $array = array('img1' => $path, 'img2' => $path2, 'id' => $battle);
    echo json_encode($array);

    }
?>
