<?php
session_start();
 ?>

<?php

  if(!isset($_SESSION['admin_session'])){
    ?>
<script type="text/javascript">
    window.location = 'Login.php';

</script>
<?php
  }else{
  ?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ADMINS AREA</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->


                    <!-- Topbar Search -->


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">

                            <!-- Dropdown - Messages -->

                        </li>

                        <!-- Nav Item - Alerts -->


                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">ADMIN</span>
                                <img class="img-profile rounded-circle" src="../BATTLEPLEX.png">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>

                <div class="row">
                    <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                    <div class="col-lg-6">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">LAUNCH BATTLE</h1>
                            </div>
                            <form class="user" action="" method="post" id="battle">
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="name1" id="name1" placeholder="1st Participent Name" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="id1" id="id1" placeholder="1st Participent Instagram Id" required>
                                </div>
                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" name="img1" id="img1" required>
                                        <label class="custom-file-label" for="customFile">Choose Participant 1 Image</label>
                                    </div>
                                </div>

                                <br>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="name2" id="name2" placeholder="2nd Participent Name" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" id="id2" name="id2" placeholder="2nd  Participent Instagram Id" required>
                                </div>

                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="image2" name="image2" required>
                                        <label class="custom-file-label" for="customFile">Choose Participant 1 Image</label>
                                    </div>
                                </div>



                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    LAUNCH
                                </button>

                                <center>

                                    <div id="errorbox">
                                        <p></p>
                                    </div>
                                </center>

                            </form>
                            <hr>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>







<?php
        if(isset($_POST['submit'])){
          session_destroy();
          ?>
<script type="text/javascript">
    window.location = '';

</script>
<?php
        }
        ?>




<script>
    $(document).ready(function() {

        $('#battle').submit(function(e) {
            e.preventDefault();





            var name1 = $('#name1').val();
            var img1 = $('#img1').val();
            var name2 = $('#name2').val();
            var img2 = $('img2').val();
            var id1 = $('#id1').val();
            var id2 = $('#id2').val();

            if (jQuery.trim(name1) == '' || jQuery.trim(name2) == '' || jQuery.trim(id1) == '' || jQuery.trim(id2) == '') {
                $('#errorbox p').html('All Fields Should Be Filled!');
            } else {




                $.ajax({
                    url: "battle.php",
                    type: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function() {
                        $('body').css('visibility', 'hidden');
                        $('#loader').css('display', 'block');
                    },
                    success: function(data) {

                       

                            $('#loader').css('display', 'none');
                            $('body').css('visibility', 'visible');
                            $img1 = data.img1;
                            $img2 = data.img2;
                            $id = data.id;
                        
                            window.location = "../INC/MAKE_THUMBNAIL.php?img1="+$img1+"&img2="+$img2+"&id="+$id+"";
                        
                    },
                    dataType: 'json'

                });




            }
        });


    });

</script>
<?php
    }

     ?>
</body>

</html>
