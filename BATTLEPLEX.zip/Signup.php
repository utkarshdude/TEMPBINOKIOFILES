<?php
session_start();
include("INC/COOKIEIP.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Utkarsh Rai">
<link rel="icon" type="image/gif/png" href="BATTLEPLEX.png">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BATTLEPLEX</title>
    <link rel="stylesheet" href="CSS/Main.css">
    <link rel="stylesheet" href="CSS/Media.css">
    <script src="JS/Jquery.js"></script>
</head>

<body>
  <?php
  if(!isset($_SESSION['LOGIN_SESSION'])){

    if(isset($_GET['Redirect'])){
      ?>
       <input type="hidden" id="redirect" value="<?php echo $_GET['Redirect']; ?>">
  <?php
    }else{
      ?>
      <input type="hidden" id="redirect" value="">
      <?php
    }
if(isset($_COOKIE['BATTLEPLEXDATA'])){
    
    include_once('CONFIG.php');
    
         $pieces = explode(",", $_COOKIE['BATTLEPLEXDATA']);
    $userid = $pieces[0];
    $pass = $pieces[1];
        
       
        
        $userid = stripslashes($userid);
      $userid = htmlspecialchars($userid, ENT_QUOTES, 'UTF-8');
      $pass = stripslashes($pass);
      $pass = htmlspecialchars($pass, ENT_QUOTES, 'UTF-8');
        
        $ciphering = "AES-128-CTR"; 
  
// Use OpenSSl Encryption method 
$iv_length = openssl_cipher_iv_length($ciphering); 
$options = 0; 
        
       $decryption_iv = '1452541536987458'; 
  
// Store the decryption key 
$decryption_key = "145fg5454f8d2f4cv8d8f5f4d98df5df64df4d4f4df4"; 
  
// Use openssl_decrypt() function to decrypt the data 
        $userid = openssl_decrypt ($userid, $ciphering,  
        $decryption_key, $options, $decryption_iv); 
        
        $pass= openssl_decrypt ($pass, $ciphering,  
        $decryption_key, $options, $decryption_iv); 
        
        
        $lgnstmt = $conn->prepare("SELECT * FROM `users` WHERE User_ID = ?");
      $lgnstmt->execute([$userid]);

      if($lgnstmt->rowCount() == 0){

        echo '<script>window.location = "Login.php";</script>';

      }else{

        $fetch = $lgnstmt->fetch(PDO::FETCH_OBJ);

        $password = $fetch->Password;
        $userID = $fetch->User_ID;



        if(password_verify($pass , $password)){

        
          $_SESSION['LOGIN_SESSION'] = $userID;
            
            echo '<script>window.location = "";</script>';

        }else{
         echo '<script>window.location = "Login.php";</script>';

        }

      }
        
        
        
    }else{
         #echo '<script>window.location = "Signup.php";</script>';
    }
  }else{

    if(isset($_GET['Redirect'])){
      echo '  <input type="hidden" id="redirect" value="'. $_GET['Redirect'] .'">';
      ?>
      <script type="text/javascript">
        window.location = "<?php echo $_GET['Redirect']; ?>";
      </script>
      <?php
    }else{
        ?>
        <script type="text/javascript">
          window.location = 'index.php';
        </script>
        <?php
    }

  }

  ?>

      <div class="header">
        <!--  <img src="BATTLEPLEX.png" alt=""> -->
      <center>  <img src="BATTLEPLEX_HEADER.png" alt=""></center>
      </div>
    <div style="margin:70px auto;" >
    
<center>
<h1 style="color:#1a1a1a; font-size:20px; ">Already Have An Account? &nbsp;&nbsp;<div style="display:inline-block;" class="extraoption2"></div></h1><br>
      <form class="" action="" id="FORMSIGNUP" method="POST">
      <input type="text" name="name" class="FormInp"  value="" placeholder="Name" required>
      <input type="email" name="email" class="FormInp"  value="" placeholder="email" required>
      <input type="password" name="pass" class="FormInp"  value="" placeholder="New Password.." required>
      <input type="password" name="cpass" class="FormInp"  value="" placeholder="Confirm New Password" required>
      <div style="width:62%; height:100px; margin:20px; display:flex; justify-content:space-between;">
        <button type="submit" id="SubmitBtn">Continue..</button>
        <div class="extraoption">

        </div>
          <script type="text/javascript">
            if($('#redirect').val() != '' && $('#redirect').val() != null){
              $('.extraoption').html('<a href="Login.php?Redirect='+$('#redirect').val()+'" style="color:#ec4d37;">Login Here..</a>');
              $('.extraoption2').html('<a href="Login.php?Redirect='+$('#redirect').val()+'" style="color:#ec4d37;"><button style="" id="SubmitBtn">Login Here..</button></a>');
            }else{
                    $('.extraoption').html('<a href="Login.php" style="color:#ec4d37;">Login Here..</a>');
                    $('.extraoption2').html('<a href="Login.php" style="color:#ec4d37;"><button style="" id="SubmitBtn">Login Here..</button></a>');
            }
          </script>

      </div>
    </form>
    <p style="color:#ff1100; font-size:15px; padding:15px;" id="errorpane"></p>
  </center>
</div>
<script src="INC/SIGNUP.js" charset="utf-8"></script>
  </body>
  </html>
